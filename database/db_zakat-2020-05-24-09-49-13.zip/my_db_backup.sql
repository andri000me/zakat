#
# TABLE STRUCTURE FOR: tbl_donatur
#

DROP TABLE IF EXISTS `tbl_donatur`;

CREATE TABLE `tbl_donatur` (
  `id_donatur` int(255) NOT NULL AUTO_INCREMENT,
  `nama_donatur` varchar(100) DEFAULT NULL,
  `alamat_donatur` text DEFAULT NULL,
  `bukti_terima` text DEFAULT NULL,
  `nominal` varchar(30) DEFAULT NULL,
  `petugas_penerima` varchar(100) DEFAULT NULL,
  `data_validation` datetime DEFAULT NULL,
  PRIMARY KEY (`id_donatur`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `tbl_donatur` (`id_donatur`, `nama_donatur`, `alamat_donatur`, `bukti_terima`, `nominal`, `petugas_penerima`, `data_validation`) VALUES (23, H. Sukani, RT 20, DONATUR_20052020161149.jpg, 300000, M. JAHID, 2020-05-20 16:11:49);
INSERT INTO `tbl_donatur` (`id_donatur`, `nama_donatur`, `alamat_donatur`, `bukti_terima`, `nominal`, `petugas_penerima`, `data_validation`) VALUES (24, Bpk Yokyok, RT 18 RW 01, DONATUR_23052020002104.jpg, 100000, ABDUL MUGHNI, 2020-05-23 00:21:04);


#
# TABLE STRUCTURE FOR: tbl_jabatan
#

DROP TABLE IF EXISTS `tbl_jabatan`;

CREATE TABLE `tbl_jabatan` (
  `id_jabatan` int(255) NOT NULL AUTO_INCREMENT,
  `nama_jabatan` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_jabatan`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `tbl_jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (1, Ketua);
INSERT INTO `tbl_jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (2, Wakil Ketua);
INSERT INTO `tbl_jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (3, Bendahara);
INSERT INTO `tbl_jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (4, Wakil Bendahara);
INSERT INTO `tbl_jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (5, Sekretaris);
INSERT INTO `tbl_jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (6, Wakil Sekretaris);
INSERT INTO `tbl_jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (7, Koordinator);
INSERT INTO `tbl_jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (8, Petugas);


#
# TABLE STRUCTURE FOR: tbl_koordinator
#

DROP TABLE IF EXISTS `tbl_koordinator`;

CREATE TABLE `tbl_koordinator` (
  `id_koor` int(11) NOT NULL AUTO_INCREMENT,
  `nama_koor` varchar(50) DEFAULT NULL,
  `panggilan_koor` varchar(100) DEFAULT NULL,
  `alamat_koor` varchar(20) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` text DEFAULT NULL,
  `ket_pass` varchar(100) DEFAULT NULL,
  `level` int(11) DEFAULT 3,
  PRIMARY KEY (`id_koor`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_koordinator` (`id_koor`, `nama_koor`, `panggilan_koor`, `alamat_koor`, `username`, `password`, `ket_pass`, `level`) VALUES (1, APRIADI SETIAWAN, ADI, RT01, adi, c46335eb267e2e1cde5b017acb4cd799, adi, 3);
INSERT INTO `tbl_koordinator` (`id_koor`, `nama_koor`, `panggilan_koor`, `alamat_koor`, `username`, `password`, `ket_pass`, `level`) VALUES (2, FAJAR NUR LABA, NUR, RT02, nur, b55178b011bfb206965f2638d0f87047, nur, 3);
INSERT INTO `tbl_koordinator` (`id_koor`, `nama_koor`, `panggilan_koor`, `alamat_koor`, `username`, `password`, `ket_pass`, `level`) VALUES (3, KHOIRUL ANAM, ANAM, RT03, anam, 80437b9dadf860bbf7bc9b469d506b9a, anam, 3);
INSERT INTO `tbl_koordinator` (`id_koor`, `nama_koor`, `panggilan_koor`, `alamat_koor`, `username`, `password`, `ket_pass`, `level`) VALUES (4, ABDUL MUGHNI, Oni, RT18, oni, cb7f4a5e75e6f7340971c99ea4587999, oni, 3);
INSERT INTO `tbl_koordinator` (`id_koor`, `nama_koor`, `panggilan_koor`, `alamat_koor`, `username`, `password`, `ket_pass`, `level`) VALUES (5, MIFTAHUDDIN, MIFTA, RT19, mifta, 150bfb5c3fcc30c477b8253721262363, mifta, 3);
INSERT INTO `tbl_koordinator` (`id_koor`, `nama_koor`, `panggilan_koor`, `alamat_koor`, `username`, `password`, `ket_pass`, `level`) VALUES (6, M. JAHID, JAHID, RT20, jahid, 5aa5aa07e7699ba95b69bd72960abf5f, jahid, 3);


#
# TABLE STRUCTURE FOR: tbl_master_alamat
#

DROP TABLE IF EXISTS `tbl_master_alamat`;

CREATE TABLE `tbl_master_alamat` (
  `id_alamat` int(255) NOT NULL AUTO_INCREMENT,
  `alamat` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id_alamat`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `tbl_master_alamat` (`id_alamat`, `alamat`) VALUES (1, RT 01);
INSERT INTO `tbl_master_alamat` (`id_alamat`, `alamat`) VALUES (2, RT 02);
INSERT INTO `tbl_master_alamat` (`id_alamat`, `alamat`) VALUES (3, RT 03);
INSERT INTO `tbl_master_alamat` (`id_alamat`, `alamat`) VALUES (4, RT 18);
INSERT INTO `tbl_master_alamat` (`id_alamat`, `alamat`) VALUES (5, RT 19);
INSERT INTO `tbl_master_alamat` (`id_alamat`, `alamat`) VALUES (6, RT 20);


#
# TABLE STRUCTURE FOR: tbl_master_kwitansi
#

DROP TABLE IF EXISTS `tbl_master_kwitansi`;

CREATE TABLE `tbl_master_kwitansi` (
  `id_kwitansi` int(11) NOT NULL AUTO_INCREMENT,
  `nama_organisasi` varchar(100) DEFAULT NULL,
  `nama_lembaga` varchar(100) DEFAULT NULL,
  `logo_organisasi` text DEFAULT NULL,
  `pembayaran` text DEFAULT NULL,
  `kota_kwitansi` varchar(30) DEFAULT NULL,
  `alamat_organisasi` text DEFAULT NULL,
  PRIMARY KEY (`id_kwitansi`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_master_kwitansi` (`id_kwitansi`, `nama_organisasi`, `nama_lembaga`, `logo_organisasi`, `pembayaran`, `kota_kwitansi`, `alamat_organisasi`) VALUES (1, Remaja Masjid Nurul Huda, Masjid Besar Nurul Huda Janti, logo_1584761457.png, Maal, Partisipasi Sosial, Infaq/Shodaqoh, Fidyah, Janti, Jl. Brigjen Katamso No.123 Janti, Waru - Sidoarjo);


#
# TABLE STRUCTURE FOR: tbl_master_laporan
#

DROP TABLE IF EXISTS `tbl_master_laporan`;

CREATE TABLE `tbl_master_laporan` (
  `id_laporan` int(11) NOT NULL AUTO_INCREMENT,
  `jabatan_laporan` varchar(100) DEFAULT NULL,
  `nama_pemilik_jabatan` varchar(100) DEFAULT NULL,
  `masehi` varchar(12) DEFAULT NULL,
  `hijriyah` varchar(12) DEFAULT NULL,
  `jabatan` varchar(100) DEFAULT NULL,
  `nama_sekretaris` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_laporan`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_master_laporan` (`id_laporan`, `jabatan_laporan`, `nama_pemilik_jabatan`, `masehi`, `hijriyah`, `jabatan`, `nama_sekretaris`) VALUES (1, Ketua Amil Zakat, Moch. Firdi Widiansya, 2020, 1441, Sekretaris, Moch. Firman Firdaus);


#
# TABLE STRUCTURE FOR: tbl_master_lokasi
#

DROP TABLE IF EXISTS `tbl_master_lokasi`;

CREATE TABLE `tbl_master_lokasi` (
  `id_lokasi` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lokasi` text DEFAULT NULL,
  `alamat_lokasi` varchar(100) DEFAULT NULL,
  `kontak_lokasi` varchar(100) DEFAULT NULL,
  `foto_lokasi` text DEFAULT NULL,
  PRIMARY KEY (`id_lokasi`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_master_lokasi` (`id_lokasi`, `nama_lokasi`, `alamat_lokasi`, `kontak_lokasi`, `foto_lokasi`) VALUES (1, Masjid Besar "Nurul Huda" Janti, Jl. Brigjen Katamso Janti, 083857151187 - 089661668843, lok_1584763357.png);


#
# TABLE STRUCTURE FOR: tbl_master_penerima
#

DROP TABLE IF EXISTS `tbl_master_penerima`;

CREATE TABLE `tbl_master_penerima` (
  `id_ket_penerima` int(11) NOT NULL AUTO_INCREMENT,
  `nama_ket` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_ket_penerima`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_master_penerima` (`id_ket_penerima`, `nama_ket`) VALUES (1, Berat);
INSERT INTO `tbl_master_penerima` (`id_ket_penerima`, `nama_ket`) VALUES (2, Ringan);
INSERT INTO `tbl_master_penerima` (`id_ket_penerima`, `nama_ket`) VALUES (3, Sabilillah);


#
# TABLE STRUCTURE FOR: tbl_panitia
#

DROP TABLE IF EXISTS `tbl_panitia`;

CREATE TABLE `tbl_panitia` (
  `id_panitia` int(255) NOT NULL AUTO_INCREMENT,
  `nama_panitia` varchar(100) DEFAULT NULL,
  `jabatan_panitia` varbinary(50) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `kontak` varchar(20) DEFAULT NULL,
  `foto_panitia` text DEFAULT NULL,
  PRIMARY KEY (`id_panitia`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: tbl_penerima_zakat
#

DROP TABLE IF EXISTS `tbl_penerima_zakat`;

CREATE TABLE `tbl_penerima_zakat` (
  `id_penerima` int(11) NOT NULL AUTO_INCREMENT,
  `nama_penerima` varchar(100) DEFAULT NULL,
  `ket_penerima` int(11) DEFAULT NULL,
  `koordinator` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_penerima`)
) ENGINE=InnoDB AUTO_INCREMENT=302 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (1, Sumarso, 1, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (2, Bu Yani, 3, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (3, Bpk Matakup, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (4, Bu Saropah, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (5, Bpk Parman, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (6, Bpk Jayadi (Sanimas), 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (7, Bu Matrio / Sampah, 1, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (8, Bu Jenjem, 1, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (9, Eka, 1, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (10, Bpk Suli, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (11, Ibu hasanah , 1, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (12, Bpk Samsul, 3, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (13, Futihatus, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (14, Bu Zubaidah, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (15, Bu Kasiah, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (16, Bu Julaika, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (17, Bpk Sumarsono, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (18, Bpk Yono, 1, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (19, Bpk Marianto , 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (20, Bpk Sahid , 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (21, Bpk Surati, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (22, Bu Sunar, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (23, Bpak hasan, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (24, Bpk Sari (Suroso) /sri utami, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (25, Bpk Soemedi, 3, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (26, Bu Fida (Qodir), 3, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (27, Bpk Hada’ (Bu Titin), 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (28, Bpk Jaiman, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (29, Bpk Paidi, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (30, Bpk Suroso (Daia), 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (31, Bu Siti, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (32, Bpk Joko, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (33, Rita, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (35, Sholeha (P. Sari), 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (36, Choirul (Dian), 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (37, ibu diana, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (38, Mad Bukhori, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (39, Bu Khomsatun, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (40, Ten / Ketang zainul , 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (41, Bpk Qodir, 3, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (42, bu juaria, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (43, Ny Muslika, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (44, Ulfa (Kost Nyoman), 1, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (45, Sowandi (Kost Suyono), 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (46, Agus Salim, 3, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (47, Abd. Rosyid, 3, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (48, M. Isa, 3, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (49, Karsimin, 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (50, Socheh, 3, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (51, Juwariyah, 3, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (53, Ibu Hamida, 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (54, Bu Nur (Pecel), 1, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (55, Sunaryo (Doyok), 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (56, H. Chamim Rosidi, 3, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (57, Abd. Ghofur, 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (58, Fatchul Korib, 1, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (59, Ach Kamaludin, 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (60, Sundari, 1, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (61, Rochimah, 3, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (63, Sua Pijet, 1, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (64, Riadi, 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (65, Kholil, 1, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (66, Ani, 1, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (67, Abd Karim, 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (68, Sriama (Pecel), 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (69, Nining (Alm Kamid) , 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (70, Zahro, 3, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (74, Martini (Kost Tulus), 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (76, Nanang (Kost Siti), 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (113, Hj. Nurul Qomariyah, 3, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (114, Bu Ameni, 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (115, Bpk Khusairi, 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (116, Bu Sumarni, 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (117, Bu Semi, 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (118, Bpk Sigit Sugiarto , 2, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (119, Bu Nur Rohmah, 3, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (120, Bpk Saki, 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (121, Bu Mudjiono, 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (122, Amal, 2, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (123, Bu Siamah, 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (124, Bu Nur Mahmuda, 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (125, Toni M, 2, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (126, Hj. Indahwati , 3, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (127, H. Anas Aly, 3, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (128, M. Munir, 3, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (129, Bpk Mat Sholehuddin , 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (130, Bu Harti (Malik), 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (131, Muhaimin (Alex), 2, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (132, Hari Setiono, 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (133, Bpk M Sofi’i, 3, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (134, Bpk Saimun, 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (135, Sunarto, 1, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (136, Mulyosantoso, 1, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (137, Mbak Tatik, 1, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (138, Mbah Mud, 1, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (139, Mbah Kamiso, 1, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (140, Mega FS, 1, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (142, Amala, 1, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (143, Misnati, 1, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (144, Latifah, 1, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (145, Mbah Ratmi, 1, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (147, Sutama, 1, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (148, Yadi, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (149, Jamila, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (150, Cak Mat Satpam, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (151, Ibu Sum, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (152, Pak Minto, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (155, Bpk. Sokib, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (156, Suryati, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (157, Khozin, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (158, Sukir, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (159, Yanto, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (160, Mujiati, 3, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (161, Dewi Asfiyah, 3, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (162, Nur Anisah, 3, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (163, Nur Sakbani, 3, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (164, Ulfa, 3, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (165, Wulan Jalil, 3, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (166, Asemah, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (167, Ulis, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (168, Ninik, 1, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (169, Fitri, 1, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (170, Bu Kadiman/Jayem, 1, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (172, Ny Sembodo, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (173, Munasri, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (174, Kholiq, 1, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (175, Bpk Ilham Kos, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (176, Imam kos Mukiyat, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (177, Gunawan Kos Yus, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (178, Endang, 3, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (179, Bunda Diyah, 3, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (180, Alm Umar Efendy, 1, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (181, Agus, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (182, Taufiq, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (183, Kusnan kos, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (184, Meme, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (185, Sunarsih, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (186, Ibu Mirna, 1, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (187, Makrufah, 1, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (188, Ibu Ulfa, 1, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (190, Bu Hindun, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (191, Rinda, 3, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (192, Asmalika, 3, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (193, Ibu Maya, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (194, Romlah, 1, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (195, Maryam , 1, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (196, Saipul kos yanto, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (209, P.panut, 3, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (210, Udin bodrex, 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (211, Harsono/ning nur, 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (213, Agus mujaidi(edi), 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (215, Bu Lek Alif, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (216, Sulika, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (217, Asmadi, 1, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (218, Lut, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (219, eka wulan, 1, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (220, bpk untung, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (221, dul hadi, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (222, sulton, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (223, bu nurul, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (224, bpk buri, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (225, irtanto, 2, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (226, Jaswadi, 2, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (227, Dani, 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (228, Tutik, 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (229, Umiyati (kos p. Ahmad), 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (230, Khundoli, 2, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (231, Mut (gorengan), 1, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (232, Abdul Kahar, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (233, Khotimah, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (234, Ning Tin, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (235, Hamzah, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (236, Sholeh, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (237, Jumadi, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (238, Ninik, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (239, Tutik, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (240, Linasih, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (241, ASiah, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (242, Sariyah, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (243, H. JUfri, 3, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (244, Yasak, 3, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (245, Dayat, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (246, Naium, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (247, Ali Usman, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (248, Rika, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (249, Lilik, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (250, Farid, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (251, Zainuri, 3, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (252, Sunarto, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (253, Edi Supriyanto, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (254, Eko, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (255, Ali Ibrahim, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (256, Ali Fathani, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (257, Fathana, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (258, Ali Mustaqim, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (259, Yulima, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (260, Buk MAr, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (261, Rokha, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (262, Mariah, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (263, Wati, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (264, Ibuk e yoyok, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (265, Aas, 3, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (266, Bu Siti, 3, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (267, Yayuk, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (268, Genduk, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (269, Sundari, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (270, Aris, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (271, Bu Suha, 1, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (272, P. Bambang, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (273, Zaky Fanani, 2, 3);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (274, Yanu, 2, 6);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (275, Misbakhul, 2, 2);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (276, Susi, 3, 1);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (277, Leo Sunaryo, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (278, Seno Susanto, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (279, Bpk. Misri, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (280, Bpk. Rokim, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (281, Bpk. Roni, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (282, Bpk. Duki, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (283, Bpk. Suhadak, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (284, Bpk. Taufik H, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (285, Ibu Lilik, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (286, Tantok, 1, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (287, Putra, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (288, Purnomo, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (289, Bamban s (ASE), 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (290, Sanjono, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (291, bpk. Putro, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (292, Bpk. Donok, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (293, Sutrisno, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (294, Sugeng R, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (295, Mbah Siti, 1, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (296, Cak mat baihaqi, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (297, Firman ady bopeng, 2, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (298, Yaati kos erwin, 2, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (299, Toari, 2, 4);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (300, Sugeng R, 2, 5);
INSERT INTO `tbl_penerima_zakat` (`id_penerima`, `nama_penerima`, `ket_penerima`, `koordinator`) VALUES (301, M amin, 2, 5);


#
# TABLE STRUCTURE FOR: tbl_user
#

DROP TABLE IF EXISTS `tbl_user`;

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(100) DEFAULT NULL,
  `nama_user` varchar(100) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` text DEFAULT NULL,
  `ket_pass` varchar(100) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_user` (`id_user`, `nama_lengkap`, `nama_user`, `username`, `password`, `ket_pass`, `level`) VALUES (1, Moch. Firman Firdaus, Firman, firman, e79c7323f62151abde47e29987b38859, akusayangkamu, 1);
INSERT INTO `tbl_user` (`id_user`, `nama_lengkap`, `nama_user`, `username`, `password`, `ket_pass`, `level`) VALUES (3, Farida Nur Zeha, Farida, admin, b34b40ca8771c48c204e55f927376885, okedeh, 1);
INSERT INTO `tbl_user` (`id_user`, `nama_lengkap`, `nama_user`, `username`, `password`, `ket_pass`, `level`) VALUES (5, Moch Firdi Widiansya, Widi, widi, f20a698699ddd337ae993089c08cd0fb, wada, 1);
INSERT INTO `tbl_user` (`id_user`, `nama_lengkap`, `nama_user`, `username`, `password`, `ket_pass`, `level`) VALUES (6, Teguh Ramadhan, Teguh, teguh, f5cd3a020bc94866049206a7cf14e266, teguh, 4);
INSERT INTO `tbl_user` (`id_user`, `nama_lengkap`, `nama_user`, `username`, `password`, `ket_pass`, `level`) VALUES (7, Bima Anugerah, Bima, bima, 7fcba392d4dcca33791a44cd892b2112, bima, 4);
INSERT INTO `tbl_user` (`id_user`, `nama_lengkap`, `nama_user`, `username`, `password`, `ket_pass`, `level`) VALUES (14, MUHAMMAD SYAHRUL QIROM, SYAHRUL, syahrul, 95ffb7a15f02c6c23f403edeae956a42, syahrul, 4);
INSERT INTO `tbl_user` (`id_user`, `nama_lengkap`, `nama_user`, `username`, `password`, `ket_pass`, `level`) VALUES (15, AULIYA ARFIANTORO, FIAN, fian, 3a63bfc12d919d317531fe8583593d7a, fian, 4);
INSERT INTO `tbl_user` (`id_user`, `nama_lengkap`, `nama_user`, `username`, `password`, `ket_pass`, `level`) VALUES (16, YULI DWI SETYAWAN, WAWAN, wawan, 0a000f688d85de79e3761dec6816b2a5, wawan, 4);
INSERT INTO `tbl_user` (`id_user`, `nama_lengkap`, `nama_user`, `username`, `password`, `ket_pass`, `level`) VALUES (17, RIZKI ZULKARNAIN, RIZKI, boboho, 8e36aec125377b008352fc32b27daf06, boboho, 4);
INSERT INTO `tbl_user` (`id_user`, `nama_lengkap`, `nama_user`, `username`, `password`, `ket_pass`, `level`) VALUES (18, Moch. Alif Rafiyuddin, Rafli, rafli, 054a3c3033e8f672358b1e159aecc7a7, rafli, 2);
INSERT INTO `tbl_user` (`id_user`, `nama_lengkap`, `nama_user`, `username`, `password`, `ket_pass`, `level`) VALUES (19, Chafidul Ahkam, hafid, hafid, f2621da6b3d4f712bf5e29861f186c7c, hafid, 4);


#
# TABLE STRUCTURE FOR: tbl_zakat_fitrah
#

DROP TABLE IF EXISTS `tbl_zakat_fitrah`;

CREATE TABLE `tbl_zakat_fitrah` (
  `id_zakat_fitrah` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pemberi_zakat` varchar(100) DEFAULT NULL,
  `besaran_jiwa` int(11) DEFAULT NULL,
  `beras` varchar(20) DEFAULT NULL,
  `uang` varchar(20) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `petugas` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_zakat_fitrah`)
) ENGINE=InnoDB AUTO_INCREMENT=422 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (1, Bapak suwandi, 1, 2.8, , RT 01, 2020-05-14, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (2, Ibu sehati, 1, 2.8, , RT 01, 2020-05-14, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (3, Marinda salsabila, 1, 2.8, , RT 01, 2020-05-14, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (4, Bapak Fauzan , 1, 2.8, , RT 01, 2020-05-14, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (5, Ibu sulastri, 1, 2.8, , RT 01, 2020-05-14, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (6, Nauval vito w, 1, 2.8, , RT 01, 2020-05-14, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (7, Donito cello a, 1, 2.8, , RT 01, 2020-05-14, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (8, Bapak Gatot, 4, 11.2, , Janti, RT 20, RW 01, 2020-05-15, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (9, Bapak ali, 3, 8.399999999999999, , RT 03 RW 01, 2020-05-16, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (10, Bpk suwadi, 3, 8.399999999999999, , Rt 03, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (11, Bpk jainuri, 2, 5.6, , Rt 03, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (12, Ibu diah, 3, 8.399999999999999, , RT 20 RW 01, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (13, Agus, 1, 2.8, , RT 20, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (14, Andiiana, 1, 2.8, , RT 20, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (15, Keisyah, 1, 2.8, , RT 20, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (16, Hafiz, 1, 2.8, , RT 20, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (17, Bu sri amah, 2, 5.6, , Janti, RT 02, RW 01, 2020-05-17, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (18, Bapak Arofiq, 2, 5.6, , Janti, RT 02, RW 01, 2020-05-17, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (19, Bapak khambali, 1, 2.8, , Janti, RT 02, RW 01, 2020-05-17, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (20, Ibu jamilah, 1, 2.8, , Janti, RT 02, RW 01, 2020-05-17, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (21, Bu siti nur khomariah, 1, 2.8, , Janti, RT 02, RW 01, 2020-05-17, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (22, Bapak Udin, 3, 8.399999999999999, , Janti, RT 02, RW 01, 2020-05-17, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (23, Bapak boedy soesanto, 6, 16.799999999999997, , Rt 19, RW 01, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (24, Septi, 2, 5.6, , RT 02 RW 01, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (25, Bpk mito, 2, 5.6, , RT 20 RW 01, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (26, M. Zuli Rohman, 1, 2.8, 32000, RT 03 RW 01, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (27, Bpk shoki, 1, 2.8, , RT 03 RW 01, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (28, Bpk ibrahim, 6, 16.799999999999997, , RT 03 RW 01, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (29, Bpk Syaichu, 3, 8.399999999999999, , RT 02 RW 01, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (30, Bpk nanang, 6, 16.799999999999997, , RT 02 RW 01, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (31, Bpk Robin, 7, 19.599999999999998, 224000, Tropodo, 2020-05-17, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (32, Ibu napsiyah, 3, 8.399999999999999, , RT.20, 2020-05-17, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (33, Febrika p., 2, 5.6, , RT.20, 2020-05-17, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (34, Bu faizatul, 2, 5.6, , RT.20, 2020-05-17, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (35, Bp. Tas'an, 2, 5.6, , RT.20, 2020-05-17, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (36, Jahid, 1, 2.8, , RT.20, 2020-05-17, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (37, Bp. Mugiono, 3, 8.399999999999999, , RT.20, 2020-05-17, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (38, Hadi z., 2, 5.6, , RT.20, 2020-05-17, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (39, Bp. Nanang, 3, 8.399999999999999, , RT.20, 2020-05-17, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (40, Bp. Roni, 4, 11.2, , RT.20, 2020-05-17, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (41, Sulanto, 4, 11.2, , RT19, 2020-05-17, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (42, Yogi, 3, 8.399999999999999, , RT19, 2020-05-17, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (44, Firman, 3, 8.399999999999999, , RT19, 2020-05-17, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (45, Agus, 2, 5.6, , RT19, 2020-05-17, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (46, Supridi, 2, 5.6, , RT19, 2020-05-17, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (47, Sugeng Purnomo, 3, 8.399999999999999, , RT19, 2020-05-17, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (48, Bapak lindung, 2, 5.6, , Wadung asri, 2020-05-18, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (49, Bu endang, 1, 2.8, , Brigjenkatamso 5 no 128, 2020-05-18, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (50, Wiwik, 3, 8.399999999999999, 96000, GSI, 2020-05-18, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (51, Nur wicaksono, 2, 5.6, 64000, Rt 01 Rw 01, 2020-05-18, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (52, Mujiono, 2, 5.6, , Janti , RT 18 RW 01, 2020-05-18, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (53, H Suprapto , 2, 5.6, , RT 18 RW01, 2020-05-18, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (54, Bpk Agus Sugiantoro, 6, 16.799999999999997, 192000, RT02 RW01, 2020-05-18, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (55, Bpk M Amin, 5, 14, , RT 19 RW01, 2020-05-18, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (56, Sugeng, 3, 8.399999999999999, , RT19, 2020-05-18, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (57, Kamiso, 1, 2.8, , RT19, 2020-05-18, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (58, Bpak Riva, 4, 11.2, 128000, RT03, 2020-05-18, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (59, Bu Susi Ani, 3, 8.399999999999999, , RT02, 2020-05-18, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (60, Bpk. Kasmidi, 5, 14, , RT02, 2020-05-18, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (61, Bpk. Abdul Karim, 4, 11.2, , RT02, 2020-05-18, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (62, Bpk. Kholil, 6, 16.799999999999997, , RT02, 2020-05-18, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (63, Ibu Khusnul, 2, 5.6, , RT03, 2020-05-18, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (64, Wahyu, 3, 8.399999999999999, , RT02, 2020-05-18, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (65, Bpk.Socheh, 5, 14, , Janti RT 02, 2020-05-18, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (66, Bapak dimas, 1, 2.8, , RT 20 RW 01, 2020-05-18, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (67, Bapak ponco, 4, 11.2, 128000, Janti, RT 20, RW 01, 2020-05-18, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (68, Bapak wahyudi, 4, 11.2, , Janti, RT 20, RW 01, 2020-05-18, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (69, Bapak eko, 4, 11.2, , RT 03 RW 01, 2020-05-18, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (70, Bu lailatul, 4, 11.2, , Janti RT 03 RW 01, 2020-05-18, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (71, Bu Ameni, 3, 8.399999999999999, , Janti RT.18, 2020-05-18, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (72, Pak Ali Mustaqim, 5, 14, , Janti RT.03, 2020-05-18, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (73, Bpk. Soemedi, 2, 5.6, , RT01, 2020-05-18, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (74, Bpk. Khoirul anam, 4, 11.2, , RT01, 2020-05-18, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (75, Bapak Mujianto, 3, 8.399999999999999, , Janti RT.19 , 2020-05-18, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (76, Bapak Bambang , 3, 8.399999999999999, , Janti RT.19, 2020-05-18, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (77, Bapak Miftahuddin, 2, 5.6, , Janti RT.19, 2020-05-18, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (78, Bp. Bisar, 4, 11.2, , RT.20, 2020-05-18, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (79, H. Sukani, 1, 2.8, , RT.20, 2020-05-18, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (80, Bpk imron, 3, 8.399999999999999, , RT 18 RW 01, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (81, Bpk sotomin, 2, 5.6, , RT 18 RW 01, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (82, Bpk sumali, 2, 5.6, , RT 03 RW 01, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (83, Bapak firman, 3, 8.399999999999999, 96000, Rt 18 Rw 01, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (84, Ibu anita, 2, 5.6, 64000, Brigjend katamso non9a, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (85, Ibu heri suhartati, 4, 11.2, , Graha tirta dahlia 3, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (86, Bpk taufik, 4, 11.2, , wisma tropodo jlm srayu block bj no 3, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (87, Bpk Much Sofii, 2, 5.6, 64000, RT 18 RW 01, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (88, Bpk adi, 4, 11.2, 128000, Graha tirta perum boughenvil, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (89, Bpk poniran, 3, 8.399999999999999, , RT 18 RW 01, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (90, Bpk jaswadi, 2, 5.6, , RT 18 RW 01, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (91, Bu nur mahmuda, 2, 5.6, , RT 18 RW 01, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (92, Bpk mulyo santoso, 5, 14, , RT 19 RW 01, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (93, Much nawawi jalaludin, 1, 2.8, , RT 18 RW 01, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (94, Bpk aris ariyanto, 4, 11.2, 128000, Balongpo, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (95, Bpk eko, 6, 16.799999999999997, 192000, Makariya, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (96, Bpk. Arif, 5, 14, , RT01, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (97, Bkp. Khamim, 3, 8.399999999999999, , RT02, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (98, Bpk. Rifki, 3, 8.399999999999999, , RT02, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (99, Bpk. Satria, 8, 22.4, , Jl. Raung No15. Pepelegi, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (100, Bpk. Mahmud, 3, 8.399999999999999, , Graha Tirta Raya, 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (101, H.Mulyadi, 1, 2.8, , RT 18 , 2020-05-19, hafid);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (102, Bpk. Abdilah Setiawan, 3, 8.399999999999999, , RT01, 2020-05-19, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (103, Bpk. Sueb, 11, 33.599999999999994, , RT18, 2020-05-19, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (104, Bpk. Misbahul arifin, 5, 14, , RT02, 2020-05-19, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (105, Wahyu Romadhony, 1, 2.8, 32000, Magetan, 2020-05-19, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (106, Bpk. Aksin, 3, 8.399999999999999, , RT02, 2020-05-19, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (107, Bpk.Burhan, 3, 8.399999999999999, , RT 02, 2020-05-19, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (109, Bpk.Purnomo, 5, 14, , RT 19, 2020-05-19, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (110, Bpk. David, 2, 5.6, , RT02, 2020-05-19, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (111, Sujito, 3, 8.399999999999999, , Rt 02, 2020-05-19, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (112, Bp. Fadil, 2, 5.6, , RT.20, 2020-05-19, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (113, Bp. Suwandi, 2, 5.6, , RT.20, 2020-05-19, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (114, Bp. Imam s., 4, 11.2, , RT.20, 2020-05-19, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (115, Bp. Mukirom, 3, 8.399999999999999, , RT.20, 2020-05-19, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (116, Rojikin, 3, 8.399999999999999, , RT.20, 2020-05-19, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (117, Bp. Mahfud, 4, 11.2, , RT.20, 2020-05-19, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (118, Candra, 1, 2.8, , RT.20, 2020-05-19, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (119, Bpk. Kojin, 2, 5.6, , RT19, 2020-05-19, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (120, Bu Suharnik, 4, 11.2, , RT19, 2020-05-19, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (121, Bapak samsul huda, 4, 11.2, , Rt 2 rw 1 jant, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (122, Bapak suryanto, 3, 8.399999999999999, , Janti rt 3 rw 1, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (123, Jamilil, 4, 11.2, , Graha tirta, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (124, Rizal, 2, 5.6, , Brigjen katamso gang V e, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (125, Rendy, 2, 5.6, , RT 18 RW 1, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (126, Ibu Aisyah, 2, 5.6, ,  RT 03 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (127, Bapak mad zakarya, 2, 5.6, , Janti rt 03 rw 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (128, Bpk. Naimun, 5, 14, , RT03, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (129, Ibu Linasih, 1, 2.8, , RT 03 , 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (130, Bapak Ardi Kushartantyo, 4, 11.2, 128000, Makarya Binangun Xa/12, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (131, Bpk Sigit, 3, 8.399999999999999, , RT 03 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (132, Ibu Siamah, 3, 8.399999999999999, , RT18 RW01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (133,  Bpk.Choiruddin , 4, 11.2, , RT 18, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (134, Bpk.Mad J, 4, 11.2, , RT 18, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (135, Bpk.Zainuri, 3, 8.399999999999999, , RT 18, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (136, Bok Rokhim, 5, 14, , Rt 19 Rw 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (137, Ibu rani, 4, 11.2, , Rt 19 Rw 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (138, Bpk Taufik, 4, 11.2, , RT 19, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (139, Bu Ismiati, 1, 2.8, , RT 19, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (140, H Jufri, 2, 5.6, , RT 03 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (141, Bpk Munasan, 5, 14, , RT 01 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (142, Bpk Sunarto, 8, 22.4, , RT 19 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (143, Hari Supriyadi, 3, 8.399999999999999, 96000, RT. 03 RT. 01 Janti, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (144, Rumanto, 2, 5.6, , Makarya Binangun H-12, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (145, Bpk Haru, 3, 8.399999999999999, 96000, RT 20 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (146, Bpk Mudji Surachman, 5, 14, , RT 18 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (147, Bpk Saiful, 4, 11.2, , RT 02, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (148, Bpk Solikin, 3, 8.399999999999999, , RT 01 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (149, Ibu Aulia Roihana, 2, 5.6, , RT 01 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (150, Bpk Ulil, 1, 2.8, , RT 01 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (151, Bpk Sapii, 3, 8.399999999999999, , RT 01 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (153, Ibu Poniati, 2, 5.6, , RT 01 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (154, Bpk Prabowo, 4, 11.2, , RT 01 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (155, Ibu Winda, 3, 8.399999999999999, , RT 01 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (156, Siska, 3, 8.399999999999999, , RT 01 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (158, M Apriadi S, 2, 5.6, , RT 01 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (159, Bpk Supri, 3, 8.399999999999999, , RT 01 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (160, Bpk Rowi, 2, 5.6, , RT 01 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (161, Bpk Hasyim, 4, 11.2, , RT 01 RW 01, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (162, Hamsah, 4, 11.2, 128000, Janti rt 03, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (163, Argi, 6, 16.799999999999997, , Janti rt 03, 2020-05-20, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (164, H. Tri Kardi. S, 3, 8.399999999999999, , Janti RT.19 RW.01, 2020-05-20, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (165, Tri Kardi Astuti, 1, 2.8, , Janti RT.19 RW.01, 2020-05-20, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (166, Bapak. H. Mutholib, 1, 2.8, , Janti RT.19 RW.01, 2020-05-20, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (167, Bp.sukarji, 2, 5.6, , RT.20, 2020-05-20, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (168, Bp. Sayuti, 1, 2.8, , RT.20, 2020-05-20, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (169, Bp.khoirul, 2, 5.6, , RT.20, 2020-05-20, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (171, Bapak isa, 7, 19.599999999999998, , Janti RT 2 RW 1, 2020-05-21, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (172, Bapak panut dan ibu sulasih, 2, 5.6, , Janti, 2020-05-21, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (173, Agus s, 5, 14, 160000, Rt 02, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (174, Anton, 12, 33.599999999999994, , Rt 19, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (175, Bp. Rahman, 3, 8.399999999999999, , Rt. 02, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (176, Mulyo H, 3, 8.399999999999999, , Rt 01, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (177, Hafidz, 3, 8.399999999999999, , Rt 02, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (178, Jihan , 1, 2.8, , Kureksari, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (179, Bp. Mansur, 5, 14, , Rt. 03, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (180, Bp. Kistoro, 2, 5.6, , Rri, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (181, Bp. Sukaji, 1, 2.8, , Rt. 18, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (182, Bp. Sobik, 2, 5.6, , Rt. 18, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (183, Siti ma'rufah, 3, 8.399999999999999, , RT.20, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (184, Siti anisa, 1, 2.8, , Siwalan kerto, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (185, Fajar H, 2, 5.6, , Siwalan kerto, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (186, Bpk Amusiri, 4, 11.2, 128000, Balongpoh, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (187, Bapak adrianto, 4, 11.2, , RT 19, RW 01, 2020-05-21, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (188, Bapak adi, 4, 11.2, , RT 19, RW 01, 2020-05-21, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (189, Mas Wawan, 3, 8.399999999999999, 96000, RT 19, 2020-05-21, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (190, Bpk Muji, 3, 8.399999999999999, , RT. 20, 2020-05-21, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (191, Syarifudin, 2, 5.6, , RT 20, 2020-05-21, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (192, Bpk Nuri, 3, 8.399999999999999, , RT 20, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (193, Bpk Alex, 3, 8.399999999999999, 96000, RT 02, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (194, Bpk Asep, 3, 8.399999999999999, , RT 02, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (195, Bpk Mahfud, 3, 8.399999999999999, , RT 19, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (196, Bapak imam, 1, 2.8, , Janti, RT 02, RW 01, 2020-05-21, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (197, Bapak arifin, 4, 11.2, , Janti, RT 02, RW 01, 2020-05-21, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (198, Pak Adi. lukmanto, 4, 11.2, 128000, Rt 18 , 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (199, Bpk Sumijo, 5, 14, , RT 01, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (200, Bu Diana, 2, 5.6, , RT 01, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (201, Bapak. Hery, 1, 2.8, , Rt 18 rw. 01, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (202, Alfin, 2, 5.6, , Rt. 03 Rw 01, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (203, Bapak. Malik, 1, 2.8, , Rt. 18 Rw 01, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (204, Bapak Subangga , 7, 19.599999999999998, 224000, Jl. Jatayu U23 - Rewwin, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (205, Ibu siti, 4, 11.2, , Janti rt.02, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (206, Bapak. Sunaryo, 11, 30.799999999999997, , Rt 1 Rw 1, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (207, Bapak nur, 2, 5.6, 64000, RT 18, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (208, Bapak Bambang, 4, 11.2, , RT 03, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (209, Bapak Irfan, 3, 8.399999999999999, , RT 03, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (210, Bapak Nasichin, 4, 11.2, 128000, RT 01, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (211, Bapak Bani, 13, 36.4, , RT 20, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (212, Bapak Taufiq, 4, 11.2, , RT 19, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (213, Maulana, 3, 8.399999999999999, , RT 19, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (214, Bapak Jalil, 4, 11.2, 128000, RT 19, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (215, Bapak Paijo Rustam, 4, 11.2, , Makarya Binangun, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (216, Riski, 1, 2.8, , RT 19, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (217, Bunda, 1, 2.8, , RT 19, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (218, Fajar nur laba, 4, 11.2, , RT 02 Rw 01, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (219, Mas andi, 4, 11.2, , RT 19 RW 01, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (220, Bapak Mangsor Ali, 5, 14, , Siwalankerto, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (221, Baitul, 1, 2.8, , RT 02, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (222, Kiara, 1, 2.8, , RT 02, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (223, Bapak Slamet, 5, 14, , RT 02, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (224, Bapak Rasidi, 3, 8.399999999999999, , RT 19, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (225, Duki Randika, 3, 8.399999999999999, , RT 19, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (226, Juanto, 2, 5.6, , RT 20, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (227, Grendis, 7, 19.599999999999998, , RT 01, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (228, Bapak Yanto, 5, 14, , RT 03, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (229, Bpk.Safrudin, 4, 11.2, , RT 02, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (230, Bpk.Narto, 4, 11.2, , RT.02, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (231, Bpk samian, 3, 8.399999999999999, , Rt. 02. Rw 01, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (233, Ghofur, 4, 11.2, , RT.20, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (234, Tugino, 2, 5.6, , RT.20, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (235, Agus, 3, 8.399999999999999, , RT.20, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (236, Alfi, 3, 8.399999999999999, , RT.20, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (237, Bu mun, 2, 5.6, , RT.20, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (238, Khasan, 2, 5.6, , RT.20, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (239, Mahfudon, 5, 14, , RT.20, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (240, Mislan, 4, 11.2, , RT.20, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (241, Feri, 3, 8.399999999999999, , RT.20, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (242, Yauman, 2, 5.6, , RT.20, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (243, Haryono, 2, 5.6, , RT.20, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (244, Minarno, 6, 16.799999999999997, , RT.20, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (245, Warto, 4, 11.2, , RT.20, 2020-05-21, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (246, Bapak Purnomo, 1, 2.8, , Janti RT.19 RW.01, 2020-05-21, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (247, Ibu Nur Majida, 1, 2.8, , Janti RT.19 RW.01, 2020-05-21, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (248, Bu Diah, 2, 5.6, , Janti RT.19 RW.01, 2020-05-21, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (249, Bapak Andri , 2, 5.6, , Janti RT.19 RW.01, 2020-05-21, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (250, Bapak Sukardi, 2, 5.6, , Janti RT.19 RW.01, 2020-05-21, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (251, Samsul, 2, 5.6, , Janti RT.19 RW.01, 2020-05-21, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (252, Bpk Rodhi, 5, 14, , RT 02, 2020-05-21, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (253, Ryan, 1, 2.8, , RT 02, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (254, Bapak Didit, 4, 11.2, , RT 02, 2020-05-21, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (255, Bapak Weli, 3, 8.399999999999999, , RT 20, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (256, Bu Rusmiati, 2, 5.6, , RT 02, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (257, Bapak Manali, 2, 5.6, , RT 03, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (258, Bapak Edi Sutrisno, 4, 11.2, 128000, RT 20, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (259, Bapak miswanto, 3, 8.399999999999999, , RT 20 RW 01, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (260, Bapak agus purnomo, 4, 11.2, , RT 20 RW 01, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (261, Ibu ifa, 3, 8.399999999999999, , RT 03 RW 01, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (262, Bpk. Salim, 5, 14, , RT02, 2020-05-22, Widi);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (263, Bpk. Sugeng Adi Purnomo, 10, 28, , RT01, 2020-05-22, Widi);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (264, Ratna, 1, 2.8, , RT19, 2020-05-22, Widi);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (265, Bpk. Sukri, 5, 14, , RT18, 2020-05-22, Widi);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (266, Bpk. Uslan, 1, 2.8, 32000, Jl. Brigjen katamso RT01 , 2020-05-22, Widi);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (267, Nasifa, Fadila, Friska, 3, 8.399999999999999, , Janti, 2020-05-22, Widi);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (268, Bpk. Sunari, 4, 11.2, , RT02, 2020-05-22, Widi);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (269, Bpk. Wahyu Triatmojo, 4, 11.2, 128000, Perum RRI Blog B13, 2020-05-22, Widi);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (270, Bpk. Dayat, 4, 11.2, , RT03, 2020-05-22, Widi);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (271, Hj. Muawanah, 1, 2.8, , RT 02 RW 01, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (272, Bapak agus, 4, 11.2, , RT 02 RW 01, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (273, H. Ruddy, 5, 14, , Jl. Bougenvil no. 74 graha tirta, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (274, Ibu Zahro, 3, 8.399999999999999, , Janti rt 2, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (275, Bapak fatkur, 4, 11.2, , Rt 18, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (277, Bpk. Allun Senjaya, 3, 8.399999999999999, 96.000, Makarya Binangun A5, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (278, Bpk Achmad junaidi a, 2, 5.6, , Rt 3 rw 01, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (279, Bpk. Anang, 5, 14, , RT20, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (280, Bpk. Kadiono, 6, 16.799999999999997, , RT01, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (281, Ibu luluk masrufah, 1, 2.8, 32000, , 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (282, Bpk Rizki, 5, 14, , Rewwin, 2020-05-22, Rafli);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (283, Bpk. Aris Cahyadi, 3, 25.2, , Jl. Brigjen Katamso, 2020-05-22, Widi);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (284, Bpk. Eko, 3, 8.399999999999999, , RT19, 2020-05-22, Widi);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (285, Bpk. Saipul, 1, 2.8, , RT18, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (286, Ugik Sutipto, 2, 5.6, , RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (287, Bapak Arif, 5, 14, , RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (288, Bpk. Ghofur, 4, 11.2, , RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (289, Bpk. Luqmanul, 3, 8.399999999999999, , RT20, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (290, Bpk. Sukirman, 3, 8.399999999999999, , RT01, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (291, Bpk. Kholil, 4, 11.2, , RT03, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (292, Bpk. Achmad, 4, 11.2, 128000, Tirta Burgenvil, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (293, Bpk. Mardi, 2, 5.6, , Janti, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (294, Bpk. Marwah Dhani, 2, 5.6, 64000, Sidoarjo, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (295, Bu Yati, 3, 8.399999999999999, , RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (296, Bapak hendra, 4, 11.2, 128000, Rt 20, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (297, Bapak samian, 4, 11.2, , Rt01, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (298, Delfi anjani, 3, 8.399999999999999, , Rt 03, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (299, Bu khotimah, 1, 2.8, , Rt 03, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (300, Pak eko, 3, 8.399999999999999, , Tirta bougenvil, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (301, Bpk. Matakub, 4, 11.2, , Janti, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (302, Bpk. Bambang, 9, 25.2, , Tirta Bugenvil 44, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (303, Mbah Sutomo, 7, 19.599999999999998, , RT01, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (304, Bpk. Samsul, 4, 11.2, , Rt02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (305, Bpk. Siswanto, 4, 11.2, , RT20, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (306, Ibu Akhadiyah, 3, 8.399999999999999, , Gg. 5 C, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (307, H. Nuril Huda, 5, 14, , RT20, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (308, Bpk. Jawani, 6, 16.799999999999997, , RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (309, Bpk. Suyanto, 3, 8.399999999999999, , Rat19, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (310, Bpk. Wawan, 2, 5.6, 64000, Gg.V 171, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (311, Bpk. Nayik, 1, 2.8, , RT03, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (312, Bpk. Iwan, 5, 14, 160000, RT07, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (313, Bpk. Rohmat T., 5, 14, , RT01, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (314, Bpk. Dicky, 5, 14, 160000, Tirta Skasiyah, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (315, Bpk. Sulton, 8, 22.4, , RT01, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (316, Bpk. Tio, 2, 5.6, , Wedoro, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (317, Bpk. Ayid, 4, 11.2, , RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (318, Bpk. Puji, 3, 8.399999999999999, , RT18, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (319, Bpk. Fajar P, 3, 8.399999999999999, , Jl. Wilis kepuh permai, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (320, Bpk. Hadi, 6, 16.799999999999997, , RT03, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (321, Ibu Umi, 2, 5.6, , RT18, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (322, Bpk. Ubed, 2, 5.6, , RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (323, Situ nur hasanah, 3, 8.399999999999999, , RT01, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (324, Bpk. Jahuri, 3, 8.399999999999999, , RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (325, Ibu sami, 4, 11.2, , RT2, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (326, Bpk. Usman, 3, 8.399999999999999, , Rt03, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (327, Bpk. Samiran, 5, 14, , RT18, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (328, Bpk. Supriono, 5, 14, , RT01, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (329, Bpk.  Ermahadi, 3, 8.399999999999999, , RT19, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (330, Bpk. Sumarlan, 4, 11.2, , RT01, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (331, Bpk. Sadali, 4, 11.2, , RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (332, Bpk. Firdaus Faisal, 3, 8.399999999999999, , RRI, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (333, Bpk. Hendri, 3, 8.399999999999999, , Janti, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (334, Bpk. Rudi, 4, 11.2, 128000, RT18, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (335, Bpk. Roykhan, 1, 2.8, 32000, RT03, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (336, Bpk. Herianto s, 6, 16.799999999999997, 192000, Ngingas, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (337, Bpk. Hendri, 2, 5.6, , RT18, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (338, Bpk. Aris b, 3, 8.399999999999999, , RT20, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (339, Bpk. Hariono, 4, 11.2, , RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (340, Bpk. Haris S, 5, 14, , Rt20, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (341, Bpk. Irianto, 3, 8.399999999999999, , RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (342, Bpk. Imron, 4, 11.2, 128000, RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (343, Bpk. Miftahul Hadi, 5, 14, , RRI, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (344, Imam Taufik, 4, 11.2, , RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (345, Ibu Sundari, 1, 2.8, , RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (346, Nuril, 1, 2.8, , RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (347, Bpk. Jupri, 3, 8.399999999999999, , RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (348, Ibu Sariya, 1, 2.8, 32000, RT03, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (349, Bpk. Asiyah, 1, 2.8, 32000, RT02, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (350, Ibu Nafsiyah, 4, 11.2, 130000, RT03, 2020-05-22, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (351, Ust abdi, 2, 5.6, , Rt 2, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (352, Bpk, supriyanto, 2, 5.6, , RT3, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (353, Bpk. Dedik M, 6, 16.799999999999997, , RT 18, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (354, Bpk. Alauddin, 4, 11.2, , Wedoro PP NOVENA, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (355, Bpk tri wijaya yulianto, ibu krisna fitriani, putri berrly, 3, 8.399999999999999, , Janti Gg 5D, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (356, Bpk. Febri, 3, 8.399999999999999, , Kavling bbc no 66, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (357, Bpk. Gunawan, 2, 5.6, , RT 01, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (358, Bpk.kurniadi, 2, 5.6, , RT 03, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (359, Bpk. Saipul, 2, 5.6, , RT 03, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (360, Yanuindri , 3, 8.399999999999999, , RT 20, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (361, Bpk. Sahid, 2, 5.6, , RT 02, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (362, Bpk. Shiwa, 4, 11.2, , Rt 2, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (363, Bpk. Sudjadmiko, 7, 19.599999999999998, , RT 18, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (364, Bpk. Heri wahyudi, 4, 11.2, 128000, Janti, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (365, Bpk. Jalil, 1, 2.8, , RT 2, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (366, Miftachur Rozzaq, 3, 8.399999999999999, , Jl. Anggrek 3 kureksari, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (367, Abah gatot, 7, 19.599999999999998, , Hanil jaya, 2020-05-23, Firman);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (368, H. Syaiful Hadi, 4, 11.2, , RT. 18 RW. 1 Janti Waru, 2020-05-23, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (369, Ari Kurniawan, 6, 16.799999999999997, , Aa, 2020-05-23, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (370, Nur Azizah, 1, 2.8, , RT. 13 RW. 02 Janti Waru, 2020-05-23, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (371, M. Hasyim, 1, 2.8, , RT. 13 RW. 02 Janti, 2020-05-23, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (372, Kevin, 1, 2.8, , RT. 13 RW. 02 Janti, 2020-05-23, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (373, Sochi Kadarusman, 2, 5.6, , RT. 20 RW. 01 Janti Waru, 2020-05-23, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (374, Iman, 1, 2.8, , Jambangan Sby, 2020-05-23, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (375, Siti Rukayah, 1, 2.8, , Jambangan Sby., 2020-05-23, FIAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (376, Rosid, 4, 11.2, , Janti RT.19 RW.01, 2020-05-23, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (377, Ibu Susana, 2, 5.6, , Janti RT.19 RW.01, 2020-05-23, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (378, Adi , 3, 8.399999999999999, , Janti RT.19 RW.01, 2020-05-23, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (379, Rama, 1, 2.8, , Janti RT.19 RW.01, 2020-05-23, SYAHRUL);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (380, Eddi darmawan, 7, 19.599999999999998, , RT.20, 2020-05-23, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (381, Saiful, 5, 14, , RT.20, 2020-05-23, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (382, Sumiati, 1, 2.8, , RT.20, 2020-05-23, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (383, Munasri, 1, 2.8, , RT.20, 2020-05-23, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (384, Topik, 5, 14, , RT.20, 2020-05-23, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (385, Angga, 4, 11.2, , RT.20, 2020-05-23, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (386, Arif, 4, 11.2, , RT.20, 2020-05-23, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (387, Gianto, 6, 16.799999999999997, , RT.20, 2020-05-23, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (388, Zainun, 1, 2.8, , RT.20, 2020-05-23, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (389, Bp.yulianto, 3, 8.399999999999999, , RT.20, 2020-05-23, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (390, Toni h., 5, 14, , RT.20, 2020-05-23, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (391, Bp. Sipin, 2, 5.6, , RT.20, 2020-05-23, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (392, Novan, 4, 11.2, , RT. 02 RW 01 Janti Waru, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (393, M. Badrul Qomar, 4, 11.2, , RT. 19 RW. 01 Janti Waru, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (394, Hamba Allah , 2, 5.6, , RT.20, 2020-05-23, WAWAN);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (395, Didik Suprianto, 6, 16.799999999999997, , RT. 18 RW. 01 Janti Waru, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (396, M. Yasin, 5, 14, , RT. 02 RW. 01 Janti Waru, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (397, Abdur Rosyid, 3, 8.399999999999999, , RT. 02 RW. 01 Janti Waru, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (398, M. Tohir, 4, 11.2, , RT. 03 RW. 01 Janti Waru, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (399, Hermanto, 1, 2.8, , RT. 18 RW. 01 Janti Waru, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (400, Kuwat, 4, 11.2, 128000, RT. 02 RW. 01 Janti Waru, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (401, Alfian Nur Rizky, 1, 2.8, , RT. 02 RW. 01 Janti Waru, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (402, Alfianti Nur Rizky, 1, 2.8, , RT. 02 RW. 01 Janti Waru, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (403, Bayu, 5, 14, , RT. 02 RW. 01 Janti Waru, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (404, Dwi Ikhmawan, 5, 14, 160000, Surabaya, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (405, Juwartatik, 2, 5.6, , RT. 19 RW. 01 Janti Waru, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (406, Deny Oktavianto, 1, 2.8, 32000, Pengkol Kedungrejo, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (407, Agus Nur Salim, 5, 14, , RT. 18 RW. 01 Janti Waru, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (408, M. Nasrullah, 5, 14, , RT. 03 RW. 01 Janti Waru, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (409, M. Rahmat Fahmi, 3, 8.399999999999999, , RT. 03 RW. 01 Janti Waru, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (410, Gus Fajar Rohmatullah, 1, 2.8, , RT 02 , 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (411, Pulung, 10, 28, 320000, Graha, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (412, Setya april, 1, 2.8, , Kedung rejo, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (413, Kusmana mandiri, 1, 2.8, , Graha, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (414, Rizki vegasari, 1, 2.8, , Graha, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (415, Deandra azzahra, 1, 2.8, , Graha, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (416, Danendra alzio, 1, 2.8, , Graha, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (417, M iswahyu, 1, 2.8, , Janti, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (418, Isnuri, 1, 2.8, , Janti, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (419, Dicky, 3, 8.399999999999999, 96000, Janti, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (420, Sulfi cahyani, 1, 2.8, , Kedung, 2020-05-23, RIZKI);
INSERT INTO `tbl_zakat_fitrah` (`id_zakat_fitrah`, `nama_pemberi_zakat`, `besaran_jiwa`, `beras`, `uang`, `alamat`, `tanggal`, `petugas`) VALUES (421, Bondan Artandyo, 5, 14, 160000, Graha Tirta Dahlia 93, 2020-05-23, RIZKI);


#
# TABLE STRUCTURE FOR: tbl_zakat_maal
#

DROP TABLE IF EXISTS `tbl_zakat_maal`;

CREATE TABLE `tbl_zakat_maal` (
  `id_zakat_maal` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pemberi_zakat` varchar(50) DEFAULT NULL,
  `kategori_zakat` varchar(30) DEFAULT NULL,
  `nominal_zakat` varchar(100) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `petugas1` varchar(30) DEFAULT NULL,
  `petugas2` varchar(30) DEFAULT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_zakat_maal`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (2, Ibu Lina , fidyah, 150000, Rewwin, 2020-05-17, hafid, , 10 Hari);
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (16, Lukman Hakim, maal, 2000000, Graha Tirta Akasia No. 36, 2020-05-13, Firman, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (17, Bu sri amah, is, 10000, Janti, RT 02, RW 01, 2020-05-17, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (18, Nanuk susilowati, fidyah, 360000, Jln dewi sartika utara 6 pnge, 2020-05-18, FIAN, , Zakan);
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (19, Wiwik, is, 4000, GSI, 2020-05-18, FIAN, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (20, Bapak Mahmud, fidyah, 120000, Janti Rt01.Rw01, 2020-05-18, RIZKI, 1, Tidak berpuasa 5 hari dikarenakan sakit);
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (21, Bu Prapto, fidyah, 240000, RT 18 RW 01, 2020-05-18, FIAN, , Sakit );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (22, Bpk Agus Sugiantoro, is, 18000, RT 02 RW 01, 2020-05-19, hafid, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (23, Bpk. Riva, is, 2000, RT03, 2020-05-18, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (24, Munfaati karimah, fidyah, 360000, RT02, 2020-05-20, FIAN, , Menyusui / 30 hari);
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (25, Bapak sigit, maal, 100000, RT 02, RW 01, 2020-05-18, Rafli, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (26, Wahyu Romadony, is, 18000, Magetan, 2020-05-19, Rafli, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (27, H. Abdul Manann, maal, 500000, Wedoro masjid, 2020-05-19, Rafli, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (28, Bpk Sunarto, is, 50000, RT 19 RW 01, 2020-05-20, FIAN, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (29, Hari Supriyadi, is, 4000, RT. 03 RW. 01 Janti Waru, 2020-05-20, FIAN, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (31, H. Sukani, is, 300000, RT 20, RW 01, 2020-05-20, Rafli, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (32, Bu suminten ( 30 hari ), fidyah, 360000, Rt. 19, 2020-05-21, WAWAN, , Lansia );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (33, Gangsar motor, maal, 750000, Janti, RT 02, RW 01, 2020-05-21, RIZKI, 2, );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (34, Bapak sunaryo, is, 50000, Rt 1 Rw 1, 2020-05-21, Rafli, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (35, Bapak Slamet, is, 50000, RT 02, 2020-05-21, Rafli, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (36, Juanto, maal, 200000, RT 20, 2020-05-21, Rafli, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (37, Bu Kikis, maal, 1000000, Makarya Binangun, 2020-05-22, Rafli, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (38, Bapak sarip, is, 100000, RT 03 RW 01, 2020-05-22, Rafli, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (39, Ibu ifa, is, 104000, RT 03 RW 01, 2020-05-22, Rafli, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (40, Bpk. Sukri, is,  250000, RT 18, 2020-05-22, Firman, 4, );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (41, Bpk. Dayat, is, 150000, RT03, 2020-05-22, Widi, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (42, Bpk. Allun senjaya, is, 4000, Makarya Bnangun a5, 2020-05-22, Rafli, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (43, Bpk. Kadiono, is, 18000, RT01, 2020-05-22, Rafli, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (44, Ibu luluk masrufah, is, 38000, , 2020-05-22, Rafli, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (45, Bpk. Samiran, is, 5000, RT18, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (46, Etik Purwoningsih, fidyah, 25 kg, RT01, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (47, Bpk.Rudi, is, 2000, RT18, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (48, Bpk. Roikhon, is, 18000, Janti, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (49, Bpk. Ahmadi, is, 8000, RT03, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (50, Ibu Hasnah, maal, 400000, RT18, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (51, Bpk. Setiawan, ps, 200000, RT02, 2020-05-22, RIZKI, 2, );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (53, Mbah Sutomo, maal, 1000000, RT01, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (54, Bpk. Aksin, is, 250000, , 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (55, Bpk. Artono, maal, 300000, RT02, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (56, Bpk. Aris Budiman, is, 200000, RT02, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (57, Bpk. Sadali, is, 250000, RT02, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (58, Bpk. Makmun, is, 300000, RT03, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (59, Bpk. Imron, maal, 300000, RT02, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (60, Bpk. Imron, is, 18000, RT02, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (61, Miftahul Hadi, is, 100000, RRI, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (62, H. Mulyadi, is, 100000, RT18, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (63, Bpk. Sumarlan, is, 150000, RT01, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (64, Ibu Linasih, fidyah, 360000, RT03, 2020-05-22, RIZKI, , Usia
);
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (65, Bpk. Bambang , maal, 2000000, Makariya Binangun R12, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (66, H. Nuril Huda, is, 200000, RT20, 2020-05-22, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (67, Bpk. Abdul rochim, maal, 100000, RT 18, 2020-05-23, Firman, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (68, Ari Kurniawan, is, 200000, RT. 18 RW. 01 Janti Waru, 2020-05-23, FIAN, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (69, Tri R., is, 400000, RT. 18 RW. 01 Janti Waru, 2020-05-23, FIAN, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (70, Bpk. Soetikno, is, 67000, RT. 18 RW. 01 Janti Waru, 2020-05-23, FIAN, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (71, H. Suyono, maal, 300000, RT20, 2020-05-23, Widi, 6, );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (72, Deny Oktavianto, is, 3000, Pengkol Kedungrejo, 2020-05-23, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (73, Aan, maal, 1000000, RT. 18, 2020-05-23, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (74, M.Nasrullah, maal, 350000, Pepelegi, 2020-05-23, RIZKI, , );
INSERT INTO `tbl_zakat_maal` (`id_zakat_maal`, `nama_pemberi_zakat`, `kategori_zakat`, `nominal_zakat`, `alamat`, `tanggal`, `petugas1`, `petugas2`, `keterangan`) VALUES (75, Desi, susanto, diego, ps, 100000, Gedangan sidoarjo, 2020-05-23, Firman, , );


